<?php
define("BASE_URL", "http://localhost/Izana_shop/");
