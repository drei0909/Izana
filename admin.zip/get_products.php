<!-- <?php
require_once('./classes/database.php');

$db = new Database();
$products = $db->getAllProducts();



header('Content-Type: application/json');
echo json_encode($products); -->
