<head>
    <link rel="icon" type="image/svg+xml" href="uploads/icon.svg">
</head>